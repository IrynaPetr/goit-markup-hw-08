# fs73

1. Питання 
2. Кахут
3. Теорія 
    3.1 Підключення стилів (Inline styles, Embedded stylesheet ,External stylesheet)
    3.2 Підключення шрифтів ( Google Fonts )
    3.3 Селектори
4. Практика 